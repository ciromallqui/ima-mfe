import { EncryptStorage } from 'encrypt-storage';

export const encryptStorage = new EncryptStorage('UwFdywoEGOt%koHlWoY!xE', {
  prefix: '@siaeva',
});
