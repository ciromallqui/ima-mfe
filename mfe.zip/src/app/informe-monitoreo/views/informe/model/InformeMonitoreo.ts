export interface InformeMonitoreo {
    orden?: number;
    usuario?: string;
    nombreInforme?: string;
    nombreInstrumento?: string;
    etapa?: string;
    nroRegistro?: string;
    estado?: string;
    fechaRegistro?: string;
    fechaCierre?: string;
    fechaPresentacion?: string;
}