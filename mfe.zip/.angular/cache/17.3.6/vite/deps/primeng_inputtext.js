import {
  InputText,
  InputTextModule
} from "./chunk-FDOEZ5MX.js";
import "./chunk-NM5SMMJJ.js";
import "./chunk-XF3YLSX2.js";
import "./chunk-AUJRVYQL.js";
import "./chunk-J4B6MK7R.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
