import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-CTDMGMAQ.js";
import "./chunk-3PIKEXR2.js";
import "./chunk-ZFU2QUHX.js";
import "./chunk-PJDXPOWT.js";
import "./chunk-LZMSIMQG.js";
import "./chunk-MSVFU3XH.js";
import "./chunk-XF3YLSX2.js";
import "./chunk-AUJRVYQL.js";
import "./chunk-J4B6MK7R.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
