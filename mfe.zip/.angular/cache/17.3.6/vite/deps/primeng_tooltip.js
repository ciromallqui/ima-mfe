import {
  Tooltip,
  TooltipModule
} from "./chunk-V43YJIMC.js";
import "./chunk-LZMSIMQG.js";
import "./chunk-MSVFU3XH.js";
import "./chunk-XF3YLSX2.js";
import "./chunk-AUJRVYQL.js";
import "./chunk-J4B6MK7R.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
