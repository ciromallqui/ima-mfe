import {
  Paginator,
  PaginatorModule
} from "./chunk-KFKCCDII.js";
import "./chunk-FDOEZ5MX.js";
import "./chunk-4TPXX2YI.js";
import "./chunk-YP3S3ITD.js";
import "./chunk-3JRL342B.js";
import "./chunk-CTDMGMAQ.js";
import "./chunk-BE5REIY4.js";
import "./chunk-3PIKEXR2.js";
import "./chunk-V43YJIMC.js";
import "./chunk-Z2B3AIZV.js";
import "./chunk-ZFU2QUHX.js";
import "./chunk-PJDXPOWT.js";
import "./chunk-LZMSIMQG.js";
import "./chunk-NM5SMMJJ.js";
import "./chunk-UGNHD22D.js";
import "./chunk-MSVFU3XH.js";
import "./chunk-XF3YLSX2.js";
import "./chunk-AUJRVYQL.js";
import "./chunk-J4B6MK7R.js";
export {
  Paginator,
  PaginatorModule
};
//# sourceMappingURL=primeng_paginator.js.map
